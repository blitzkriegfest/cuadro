<?php

class Example_model extends Crud_model
{
 #
}
