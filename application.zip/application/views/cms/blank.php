

<!--main content start-->
<section id="main-content">
  <section class="wrapper site-min-height">
    <!-- page start-->
    Page content goes here
    <!-- page end-->
  </section>
</section>
<!--main content end-->
