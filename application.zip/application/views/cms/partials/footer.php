<!--footer start-->
<footer class="site-footer">
    <div class="text-center">
        2013 &copy; FlatLab by VectorLab.
        <a href="#" class="go-top">
            <i class="fa fa-angle-up"></i>
        </a>
    </div>
</footer>
<!--footer end-->
</section>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url('public/admin/'); ?>js/bootstrap.min.js"></script>
<script class="include"  src="<?php echo base_url('public/admin/'); ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo base_url('public/admin/'); ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo base_url('public/admin/'); ?>js/slidebars.min.js"></script>
<script src="<?php echo base_url('public/admin/'); ?>js/jquery.nicescroll.js" ></script>
<script src="<?php echo base_url('public/admin/'); ?>js/respond.min.js" ></script>

<!-- dynamic table -->
<script type="text/javascript" language="javascript" src="<?php echo base_url('public/admin/'); ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url('public/admin/'); ?>assets/data-tables/DT_bootstrap.js"></script>
<script  src="<?php echo base_url('public/admin/'); ?>js/dynamic_table_init.js"></script>


<!--common script for all pages-->
<script src="<?php echo base_url('public/admin/'); ?>js/common-scripts.js"></script>



</body>
</html>
